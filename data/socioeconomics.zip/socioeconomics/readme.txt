-Població.habitants i densitat de població per km2. 
Periode 2020-2000.
Font: IDESCAT

-Nivell de renda: Renda familiar disponible bruta territorial per habitant.
Periode 2019-2010. 
Unitats en milers d'euros
Font: IDESCAT i INE

-Productivitat. PIB territorial per capita per municipi. 
Periode 2019-2011.
FONT: IDESCAT

-Atur:nombre de persones aturades als municipis. 
Periode 2021-2005.
FONT:SEPE

-Desigualtat: Index de Gini. 
Periode 2019-2015.
Font: INE

-Inmigració.% de poblacio extrangera respecte al total del municipi. 
Periode 2020-2000.
Font: IDESCAT

-Nivell Socioeconòmic. Índex Socioeconòmic Territorial. 
Període 2019-2015.
Font: IDESCAT

-Habitatge: demanda habitatge. Persones inscrites en el Registre de Sol·licitants d'habitatges amb protecció oficial. 
Periode 2020-2012.
Font: Secretaria d'Habitatge i Inclusió Social

-Formació. Població amb estudis baixos. Percentatge de població de 20 o més anys que és analfabeta o té com a molt estudis de primària. Correspon als nivells 0 i 1 de la classificació CCED-2020 (A).
Periode 2019-2015.
Font: IDESCAT

-Innovació. Patents totals registrades per municipi. 
Periode 2015-2005
Font: PATSTAT